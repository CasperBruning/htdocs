<?php

// Database variables

const DB_HOST = "localhost";
const DB_NAME = "gemeentewebsite"; //of vul andere naam in
const DB_USER = "root";
const DB_PASSWORD = "";