<?php
require 'header.php'?>

<div>
    <h1 class="title1">U bent nu ingelogd</h1>

</div>

<div><p>test</p></div>





<?php require 'footer.php'?>