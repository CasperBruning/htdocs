// document.querySelector(`#ingelogd`).addEventListener('click', () =>{
//     alert("Je bent nu ingelogd en word teruggestuurd naar de hoofdpagina")
// })