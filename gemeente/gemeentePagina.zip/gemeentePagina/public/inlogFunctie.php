<?php
if (isset($_POST['submit'])){

    db_insertData("SELECT * FR");

}
