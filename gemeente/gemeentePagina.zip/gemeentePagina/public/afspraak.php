<?php require 'header.php' ?>
<a href="paspoort.php"><img class="returnimg" src="img/return..png"></a>
<h1 class="title1">Afspraak maken </h1>
<section class="text-center bg-light features-icons">
    <div></div>
    <div class="container">
        <p><strong>Online Regelen</strong>
            <br>Veel zaken kunt u ook online regelen via onze website. U hoeft hiervoor dan niet naar het gemeentehuis
            te komen, maar regelt het vanuit huis.<br>Kijk bij het product van uw keuze&nbsp;of dit al digitaal mogelijk
            is.<br><br></p>
        <p><strong>&nbsp;Wij werken op afspraken.</strong><br>Om u zo goed mogelijk te kunnen helpen en te weten
            waarvoor u komt werken wij op afspraak. Dit voorkomt voor u langere wachttijden.<br>Alleen voor het OPHALEN
            van uw paspoort, identiteitsbewijs, rijbewijs of gehandicaptenparkeerkaart hoeft u geen afspraak te
            maken.<br><br><strong>Afspraak maken</strong><br>U kunt voor de volgende producten direct online een
            afspraak maken:<br><br>-<a
                    href="https://afspraak.oude-ijsselstreek.nl:8443/services/6bbff6f8b6a198e2adef5e760a9d075e132280d35ba0dacb0d45e005348da872">Rijbewijs
                aanvragen of vernieuwen</a><br>-<a
                    href="https://afspraak.oude-ijsselstreek.nl:8443/services/e64789e4ba078ad9a477b95fff362b9a273186fc6c6c9a811f082651f72ac75e">Paspoort
                aanvragen of vernieuwen</a><br>-<a
                    href="https://afspraak.oude-ijsselstreek.nl:8443/services/e98f2f150fcf4209b9b27143e15d9b4bd8de8eea970e58676e8e025ebc873532">Verlies
                of diefstal rijbewijs</a>&nbsp;(dit kunt u ook&nbsp;<a
                    href="https://www.rdw.nl/particulier/voertuigen/auto/het-rijbewijs/rijbewijs-kwijt-of-gestolen">online
                melden op de site van het CBR</a>)<br>-<a
                    href="https://afspraak.oude-ijsselstreek.nl:8443/services/36a9f561480fb5af5f437e76dc445a398f77ba6877771e47a89c1e59c7a24ce5">Verlies
                of diefstal paspoort of ID-kaart</a>&nbsp;(dit kunt u ook&nbsp;<a
                    href="https://edienstenburgerzaken.oude-ijsselstreek.nl/VermissingReisdocument/Login/">online&nbsp;melden
                op onze site</a>)<br>-<a
                    href="https://afspraak.oude-ijsselstreek.nl:8443/services/7fb00a0ef76b8f6e508b86133ef980903081e190d0af235782acbe5df3fe5f02">Identiteitskaart
                aanvragen of vernieuwen</a><br>-<a
                    href="https://afspraak.oude-ijsselstreek.nl:8443/services/e64789e4ba078ad9a477b95fff362b9a273186fc6c6c9a811f082651f72ac75e">Zakenpaspoort
                aanvragen of vernieuwen</a><br>-<a
                    href="https://afspraak.oude-ijsselstreek.nl:8443/services/e64789e4ba078ad9a477b95fff362b9a273186fc6c6c9a811f082651f72ac75e">Tweede
                paspoort aanvragen</a><br>-<a
                    href="https://afspraak.oude-ijsselstreek.nl:8443/services/8eb13e0de0e095ab2df642ca45d30a3eaf6e0a9a1b153425d985195868cdd710">Uittreksel
                basisregistratie personen (BRP) aanvragen</a>&nbsp;(dit kunt u ook&nbsp;<a
                    href="https://edienstenburgerzaken.oude-ijsselstreek.nl/Uittreksel/Login/">online&nbsp;aanvragen</a>)<br>-<a
                    href="https://afspraak.oude-ijsselstreek.nl:8443/services/8eb13e0de0e095ab2df642ca45d30a3eaf6e0a9a1b153425d985195868cdd710">Uittreksel
                burgerlijke stand aanvragen</a>&nbsp;(dit kunt u ook&nbsp;<a
                    href="https://edienstenburgerzaken.oude-ijsselstreek.nl/AfschriftBurgerlijkeStand/Login/">online&nbsp;aanvragen</a>)<br>-<a
                    href="https://afspraak.oude-ijsselstreek.nl:8443/services/8eb13e0de0e095ab2df642ca45d30a3eaf6e0a9a1b153425d985195868cdd710">Bewijs
                van in leven zijn aanvragen</a><br>-<a
                    href="https://afspraak.oude-ijsselstreek.nl:8443/services/8eb13e0de0e095ab2df642ca45d30a3eaf6e0a9a1b153425d985195868cdd710">Attestatie
                de vita aanvragen</a><br>-<a
                    href="https://afspraak.oude-ijsselstreek.nl:8443/services/bab8ad9847348f4e4b89329ddb249518afeecfb7093a7c8bc33a91888481e89a">Verklaring
                omtrent gedrag aanvragen</a>&nbsp;(dit kunt u ook&nbsp;<a
                    href="https://mijn.oude-ijsselstreek.nl/auth/digid?success_endpoint=https%3A%2F%2Fmijn.oude-ijsselstreek.nl%2Fzaak%2Fcreate%2Fwebformulier%2F%3Fzaaktype_id%3D42%26sessreset%3D1%26ztc_aanvrager_type%3Dnatuurlijk_persoon%26authenticatie_methode%3Ddigid">online&nbsp;aanvragen</a>)<br>-<a
                    href="https://afspraak.oude-ijsselstreek.nl:8443/services/9be78e9625f1be98cc4cf6364b6c9e6e70e90c0cc3b53d4f230042326f653461">Legaliseren
                handtekening</a><br>-<a href="https://www.oude-ijsselstreek.nl/verhuizen-inschrijven-oude-ijsselstreek">Verhuizing
                doorgeven</a>&nbsp;(dit kunt u ook&nbsp;<a
                    href="https://edienstenburgerzaken.oude-ijsselstreek.nl/Verhuizen/Login/">online&nbsp;doorgeven</a>)<br><br>Wilt
            u voor een ander product een afspraak maken, of wilt u voor meer dan één product een afspraak maken? U kunt
            telefonisch een afspraak maken.<br>Ons telefoonnummer is 0315-292292.&nbsp;Kijk bij onze&nbsp;<a
                    href="https://www.oude-ijsselstreek.nl/openingstijden">openingstijden</a>&nbsp;waarbinnen wij voor u
            een afspraak kunnen plannen.<br><br><strong>Belangrijk:</strong><br>Tussen het aanvragen en het kunnen
            ophalen van een paspoort/ID-kaart of rijbewijs houden wij een week aan. Verloopt uw ID-kaart bijvoorbeeld
            eind december,<br>maak dan voor half december een afspraak. Moet u nog gekeurd worden voor uw rijbewijs?
            Plan dan ruim 4 maanden van tevoren een<br>afspraak voor het aanvragen van een gezondheids(medische)
            verklaring. Deze kunt u bij de gemeente, maar ook bij het&nbsp;<a
                    href="https://www.cbr.nl/nl/rijbewijs-houden/nl/gezondheidsverklaring.htm">CBR</a>&nbsp;aanvragen.<br>Let
            op: ook voor het aanvragen van een gezondheidsverklaring moet u een afspraak maken.<br>_____________________________________________________________________________________________________________________________________________________________________________________________________________<br><br><strong>Geboortedatum
                voor identificatie</strong><br>Maakt u een afspraak? Dan wordt uw geboortedatum gevraagd. Deze datum
            wordt gebruikt om u te kunnen aanmelden bij de zuil bij de ingang.<br><br><strong>Wat moet u
                doen:</strong><br>Bij de zuil wordt gevraagd of u een afspraak heeft.<br>U klikt op JA, dan wordt uw
            geboortedatum gevraagd, waarbij u uw 8-cijferige geboortedatum in moet voeren. Bijvoorbeeld: 25-02-2025.<br>Heeft
            u dit gedaan, dan verschijnt er een ticket met een nummer. U kunt plaats nemen in de wachtruimte en kunt op
            het tv-scherm zien wanneer u<br>opgeroepen wordt en bij welke balie u verwacht wordt.<br>Komt u 15 minuten
            te vroeg, dan lukt het nog niet om u aan te melden voor uw afspraak. U moet dan nog even wachten.<br>Lukt
            het aanmelden niet, dan helpt een medewerker van de receptie u graag verder.<br><br><strong>Dienstverlening
                vanwege coronavirus</strong><br>De dienstverlening van de gemeente gaat door. Maar we nemen wel
            maatregelen om onnodig risico op verspreiding van het Coronavirus te voorkomen.<br>Daarvoor vragen we ook uw
            medewerking.<br><br>U blijft welkom in het gemeentehuis in Gendringen. Uiteraard geldt nog steeds: heeft u
            klachten zoals neusverkoudheid, hoesten, keelpijn of koorts?<br>Kom dan niet naar het gemeentehuis en blijf
            thuis.<br><br><br></p>
    </div>
</section>
<section class="showcase"></section>

<?php require 'footer.php' ?>
