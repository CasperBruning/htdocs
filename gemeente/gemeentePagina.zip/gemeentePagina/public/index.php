<?php require 'header.php'?>
    <a><img class="invisibleReturnImg" src="img/return..png"></a>
    <h1 class="title1">Maak een keuze</h1>
<section class="text-center bg-light features-icons">
    <div></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <p></p>
                <div class="mx-auto features-icons-item mb-5 mb-lg-0 mb-lg-3"></div>
                <p><i class="fa fa-id-card-o idCardPictureMenu" style="font-size: 63px;color: var(--bs-blue);margin-left: 80px;"></i></p><a class="textButton1" href="paspoortEnIdKeuzeMenu.php" style="font-size: 20px;"><strong>Paspoort en ID-kaart</strong></a>
            </div>
            <div class="col-lg-4">
                <div class="mx-auto features-icons-item mb-5 mb-lg-0 mb-lg-3"></div>
                <p><i class="fa fa-folder-o vergunningPictureMenu" style="font-size: 63px;color: var(--bs-blue);margin-left: 80px;"></i><br></p><a class="textButton2" href="vergunningenKeuzeMenu.php" style="font-size: 20px;">Vergunningen</a>
            </div>
            <div class="col-lg-4">
                <p><i class="fa fa-trash-o afvalPictureMenu" style="font-size: 63px;color: var(--bs-blue);margin-left: 80px;"></i></p>
                <div class="mx-auto features-icons-item mb-5 mb-lg-0 mb-lg-3">
                    <div class="d-flex features-icons-icon"><a class="textButton3" href="#" style="font-size: 20px;">Afval</a></div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-4">
                <div class="mx-auto features-icons-item mb-5 mb-lg-0 mb-lg-3"></div>
                <p><i class="fa fa-money belastingIconMenu" style="font-size: 63px;color: var(--bs-blue);margin-left: 80px;"></i></p><a class="textButton1" href="#" style="font-size: 20px;">Belastingen</a>
            </div>
            <div class="col-lg-4">
                <div class="mx-auto features-icons-item mb-5 mb-lg-0 mb-lg-3"></div>
                <p></p>
                <p><i class="fa fa-user sociaalDomeinPictureMenu" style="font-size: 63px;color: var(--bs-blue);margin-left: 80px;"></i></p><a class="textButton1" href="#" style="font-size: 20px;">Sociaal Domein</a>
            </div>
            <div class="col-lg-4">
                <p><i class="fa fa-user trouwenPictureMenu" style="font-size: 63px;color: var(--bs-blue);margin-left: 80px;"></i><i class="fa fa-user trouwenPictureMenu" style="font-size: 63px;color: var(--bs-blue);"></i></p>
                <div class="mx-auto features-icons-item mb-5 mb-lg-0 mb-lg-3">
                    <div class="d-flex features-icons-icon"><a class="textButton6" href="#" style="font-size: 20px;">Trouwen</a></div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="showcase"></section>

<?php require 'footer.php'?>