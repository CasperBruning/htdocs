<?php require 'header.php'?>
<a href="index.php"><img class="returnimg" src="img/return..png"></a>
<h1 class="title1">Paspoort en ID </h1>
<section class="text-center bg-light features-icons">
    <div></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <p></p>
                <div class="mx-auto features-icons-item mb-5 mb-lg-0 mb-lg-3"></div>
                <p><i class="fa fa-book idCardPictureMenu" style="font-size: 63px;color: var(--bs-blue);margin-left: 80px;"></i></p><a class="textButton1" href="paspoort.php" style="font-size: 20px;"><strong>Paspoort</strong></a>
            </div>
            <div class="col-lg-4">
                <div class="mx-auto features-icons-item mb-5 mb-lg-0 mb-lg-3"></div>
                <p><i class="fa fa-id-card-o vergunningPictureMenu" style="font-size: 63px;color: var(--bs-blue);margin-left: 80px;"></i><br></p><a class="textButton2" href="#" style="font-size: 20px;">ID-Kaart</a>
            </div>
            <div class="col-lg-4">
                <p><i class="fa fa-lock afvalPictureMenu" style="font-size: 63px;color: var(--bs-blue);margin-left: 80px;"></i></p>
                <div class="mx-auto features-icons-item mb-5 mb-lg-0 mb-lg-3">
                    <div class="d-flex features-icons-icon"><a class="textButton3" href="#" style="font-size: 20px;">Diefstal of vermissing van ID-kaart of paspoort</a></div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-4">
                <div class="mx-auto features-icons-item mb-5 mb-lg-0 mb-lg-3"></div>
                <p></p><i class="fa fa-user trouwenPictureMenu" style="font-size: 63px;color: var(--bs-blue);margin-left: 80px;"></i><i class="fa fa-user trouwenPictureMenu" style="font-size: 63px;color: var(--bs-blue);transform: scale(0.70);"></i><a class="textButton1" href="#" style="font-size: 20px;">Reizen met kinderen</a>
            </div>
            <div class="col-lg-4">
                <div class="mx-auto features-icons-item mb-5 mb-lg-0 mb-lg-3">
                    <p></p>
                    <p></p>
                </div><i class="fa fa-book sociaalDomeinPictureMenu" style="font-size: 63px;color: var(--bs-blue);margin-left: 80px;transform: scale(1);opacity: 1;"></i><i class="fa fa-book sociaalDomeinPictureMenu2" style="font-size: 63px;color: var(--bs-blue);margin-left: 0px;transform: scale(0.70);opacity: 1;"></i><a class="textButton1" href="#" style="font-size: 20px;">Tweede paspoort</a>
            </div>
            <div class="col-lg-4">
                <p></p><i class="fa fa-lock afvalPictureMenu" style="font-size: 63px;color: var(--bs-blue);margin-left: 80px;"></i><i class="fa fa-lock afvalPictureMenu" style="font-size: 63px;color: var(--bs-blue);margin-left: 0px;transform: scale(0.70);"></i>
                <div class="mx-auto features-icons-item mb-5 mb-lg-0 mb-lg-3">
                    <div class="d-flex features-icons-icon"><a class="textButton6" href="#" style="font-size: 20px;">Diefstal of vermissing van rijbewijs&nbsp;</a></div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="showcase"></section>

<?php require 'footer.php'?>
