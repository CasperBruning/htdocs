<?php
$oudPrijs = 20;
$nieuwPrijs= 25;
$resultaat = procentBerekenen($oudPrijs, $nieuwPrijs);
echo $resultaat;




function procentBerekenen($oudPrijs, $nieuwPrijs){
    $berekening = $oudPrijs - $nieuwPrijs / 100;
    $berekening.round($berekening,0);
    $resultaat = "Korting is: " . $berekening . "%";

    return $resultaat;
}

